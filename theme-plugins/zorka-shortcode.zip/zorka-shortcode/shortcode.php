<?php
/**
 * Plugin Name: Zorka Shortcode
 * Plugin URI: http://g5plus.net
 * Description: This is plugin that create shortcode of theme
 * Version: 1.0
 * Author: g5plus
 * Author URI: http://g5plus.net
 * License: GPLv2 or later
 */
// don't load directly
if ( ! defined( 'ABSPATH' ) ) die( '-1' );
if(! function_exists('g5plus_getCSSAnimation')){
    function g5plus_getCSSAnimation( $css_animation ) {
        $output = '';
        if ( $css_animation != '' ) {
            wp_enqueue_script( 'waypoints' );
            $output = ' wpb_animate_when_almost_visible g5plus-css-animation wpb_' . $css_animation;
        }
        return $output;
    }
}
if(! function_exists('g5plus_getStyleAnimation')){
    function g5plus_getStyleAnimation( $duration,$delay ) {
        $duration=esc_attr($duration);
        $delay=esc_attr($delay);
        $styles = array();
        if ( $duration != '0' && ! empty( $duration ) ) {
            $duration = (float)trim( $duration, "\n\ts" );
            $styles[] = "-webkit-animation-duration: {$duration}s";
            $styles[] = "-moz-animation-duration: {$duration}s";
            $styles[] = "-ms-animation-duration: {$duration}s";
            $styles[] = "-o-animation-duration: {$duration}s";
            $styles[] = "animation-duration: {$duration}s";
        }
        if ( $delay != '0' && ! empty( $delay ) ) {
            $delay = (float)trim( $delay, "\n\ts" );
            $styles[] = "opacity: 0";
            $styles[] = "-webkit-animation-delay: {$delay}s";
            $styles[] = "-moz-animation-delay: {$delay}s";
            $styles[] = "-ms-animation-delay: {$delay}s";
            $styles[] = "-o-animation-delay: {$delay}s";
            $styles[] = "animation-delay: {$delay}s";
        }
        if (count($styles) > 1) {
            return 'style="'. implode( ';', $styles ).'"';
        }
        return implode( ';', $styles );
    }
}
$dir = plugin_dir_path( __FILE__ );
include_once($dir.'vc-extend/vc-extend.php');
include_once($dir.'heading/heading.php');
include_once($dir.'call-action/call-action.php');
include_once($dir.'parallax-sections/parallax-sections.php');
include_once($dir.'button/button.php');
include_once($dir.'counter/counter.php');
include_once($dir.'icon-box/icon-box.php');
include_once($dir.'partner-carousel/partner-carousel.php');
include_once($dir.'our-team/our-team.php');
include_once($dir.'testimonial/testimonial.php');
include_once($dir.'mailchimp/mailchimp.php');
include_once($dir.'banner/banner.php');
include_once($dir.'portfolio/portfolio.php');
include_once($dir.'products/sale-product.php');
include_once($dir.'products/trending-product.php');
include_once($dir.'products/product-categories.php');
include_once($dir.'latest-post/latest-post.php');

if(!class_exists('Zorka_Shortcode')){
    class Zorka_Shortcode{
        function __construct(){
            add_action('init', array($this,'register_vc_map'),10);

        }
        function register_vc_map()
        {
            if ( function_exists( 'vc_map' ) ) {
                $add_css_animation = array(
                    'type' => 'dropdown',
                    'heading' => __( 'CSS Animation', 'zorka' ),
                    'param_name' => 'css_animation',
                    'admin_label' => true,
                    'value' => array(
                        __( 'No', 'zorka' ) => '',
                        __( 'Top to bottom', 'zorka' ) => 'top-to-bottom',
                        __( 'Bottom to top', 'zorka' ) => 'bottom-to-top',
                        __( 'Left to right', 'zorka' ) => 'left-to-right',
                        __( 'Right to left', 'zorka' ) => 'right-to-left',
                        __( 'Appear from center', 'zorka' ) => 'appear',
                        __( 'FadeIn', 'zorka' ) => 'fadein'
                    ),
                    'description' => __( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'js_composer' )
                );
                $add_duration_animation= array(
                    'type' => 'textfield',
                    'heading' => __( 'Animation Duration', 'zorka' ),
                    'param_name' => 'duration',
                    'value' => '',
                    'description' => __( 'Duration in seconds. You can use decimal points in the value. Use this field to specify the amount of time the animation plays. <em>The default value depends on the animation, leave blank to use the default.</em>', 'zorka' ),
                    'dependency'  => Array( 'element' => 'css_animation', 'value' => array( 'top-to-bottom','bottom-to-top','left-to-right','right-to-left','appear','fadein') ),
                );
                $add_delay_animation=array(
                    'type' => 'textfield',
                    'heading' => __( 'Animation Delay', 'zorka' ),
                    'param_name' => 'delay',
                    'value' => '',
                    'description' => __( 'Delay in seconds. You can use decimal points in the value. Use this field to delay the animation for a few seconds, this is helpful if you want to chain different effects one after another above the fold.', 'zorka' ),
                    'dependency'  => Array( 'element' => 'css_animation', 'value' => array( 'top-to-bottom','bottom-to-top','left-to-right','right-to-left','appear','fadein') ),
                );
                $add_el_class = array(
                    'type'        => 'textfield',
                    'heading'     => __( 'Extra class name', 'zorka' ),
                    'param_name'  => 'el_class',
                    'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'zorka' ),
                );
                $colors_arr = array(
                    __( 'Zorka Color', 'zorka' ) => 'zorka_color',
                    __( 'Grey', 'zorka' ) => 'wpb_button',
                    __( 'Blue', 'zorka' ) => 'btn-primary',
                    __( 'Turquoise', 'zorka' ) => 'btn-info',
                    __( 'Green', 'zorka' ) => 'btn-success',
                    __( 'Orange', 'zorka' ) => 'btn-warning',
                    __( 'Red', 'zorka' ) => 'btn-danger',
                    __( 'Black', 'zorka' ) => "btn-inverse"
                );
                $target_arr = array(
                    __( 'Same window', 'zorka' ) => '_self',
                    __( 'New window', 'zorka' ) => '_blank'
                );
                vc_map( array(
                    'name'     => __( 'Headings', 'zorka' ),
                    'base'     => 'zorka_heading',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3', __( 'style 4', 'zorka' ) => 'style4'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                            'admin_label' => true,
                        ),
                        array(
                            'type'        => 'textarea',
                            'heading'     => __( 'Description', 'zorka' ),
                            'param_name'  => 'description',
                            'value'       => '',
                            'description' => __( 'Provide the description for this heading', 'zorka' ),
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1','style3') ),
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Call To Action', 'zorka' ),
                    'base'     => 'zorka_call_action',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3', __( 'style 4', 'zorka' ) => 'style4', __( 'style 5', 'zorka' ) => 'style5'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type' => 'attach_image',
                            'heading' => __( 'Background Images', 'zorka' ),
                            'param_name' => 'bg_images',
                            'value' => '',
                            'description' => __( 'Select images from media library.', 'zorka' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textarea',
                            'heading'    => __( 'Description', 'zorka' ),
                            'param_name' => 'description',
                            'value'      => '',
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1','style3') )
                        ),
                        array(
                            'type'        => 'icon_text',
                            'heading'     => __( 'Select Icon:', 'zorka' ),
                            'param_name'  => 'icon',
                            'value'       => '',
                            'description' => __( 'Select the icon from the list.', 'zorka' ),
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style2') )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button Label', 'zorka' ),
                            'param_name' => 'button_label',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Link (url)', 'zorka' ),
                            'param_name' => 'link',
                            'value'      => '',
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Open link in a new window/tab', 'zorka' ),
                            'param_name' => 'link_target',
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Parallax Sections', 'zorka' ),
                    'base'     => 'zorka_parallax_sections',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textarea',
                            'heading'    => __( 'Description', 'zorka' ),
                            'param_name' => 'description',
                            'value'      => '',
                        ),
                        array(
                            'type'        => 'icon_text',
                            'heading'     => __( 'Select Icon:', 'zorka' ),
                            'param_name'  => 'icon',
                            'value'       => '',
                            'description' => __( 'Select the icon from the list.', 'zorka' ),
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style2') )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button 1: Label', 'zorka' ),
                            'param_name' => 'bt1_label',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button 1: Link (url)', 'zorka' ),
                            'param_name' => 'bt1_link',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'checkbox',
                            'heading'    => __( 'Button 1: Open link in a new window/tab', 'zorka' ),
                            'param_name' => 'bt1_link_target',
                            'value'      => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button 2: Label', 'zorka' ),
                            'param_name' => 'bt2_label',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button 2: Link (url)', 'zorka' ),
                            'param_name' => 'bt2_link',
                            'value'      => '',
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Button 2: Open link in a new window/tab', 'zorka' ),
                            'param_name' => 'bt2_link_target',
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Button', 'zorka' ),
                    'base'     => 'zorka_button',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3', __( 'style 4', 'zorka' ) => 'style4'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Size', 'zorka' ),
                            'param_name'  => 'size',
                            'admin_label' => true,
                            'value'       => array( __( 'small', 'zorka' ) => 'button-sm', __( 'medium', 'zorka' ) => 'button-md', __( 'large', 'zorka' ) => 'button-lg'),
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Button Label', 'zorka' ),
                            'param_name' => 'button_label',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Link (url)', 'zorka' ),
                            'param_name' => 'link',
                            'value'      => '',
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Open link in a new window/tab', 'zorka' ),
                            'param_name' => 'link_target',
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Banner', 'zorka' ),
                    'base'     => 'zorka_banner',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title 1', 'zorka' ),
                            'param_name' => 'title1',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title 2', 'zorka' ),
                            'param_name' => 'title2',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textarea',
                            'heading'    => __( 'Description', 'zorka' ),
                            'param_name' => 'description',
                            'value'      => '',
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Counter', 'zorka' ),
                    'base'     => 'zorka_counter',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Value', 'zorka' ),
                            'param_name' => 'value',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                        ),
                        $add_el_class
                    )
                ) );
                vc_map( array(
                    'name' => __( 'Pie chart', 'vc_extend' ),
                    'base' => 'vc_pie',
                    'class' => '',
                    'icon' => 'icon-wpb-vc_pie',
                    "category" => __( 'Zorka Shortcodes', 'zorka' ),
                    'description' => __( 'Animated pie chart', 'zorka' ),
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Pie value', 'zorka' ),
                            'param_name' => 'value',
                            'description' => __( 'Input graph value here. Choose range between 0 and 100.', 'zorka' ),
                            'value' => '50',
                            'admin_label' => true
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Pie label value', 'zorka' ),
                            'param_name' => 'label_value',
                            'description' => __( 'Input integer value for label. If empty "Pie value" will be used.', 'zorka' ),
                            'value' => ''
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Units', 'zorka' ),
                            'param_name' => 'units',
                            'description' => __( 'Enter measurement units (if needed) Eg. %, px, points, etc. Graph value and unit will be appended to the graph title.', 'zorka' )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => __( 'Bar color', 'zorka' ),
                            'param_name' => 'color',
                            'value' => $colors_arr, //$pie_colors,
                            'description' => __( 'Select pie chart color.', 'zorka' ),
                            'admin_label' => true,
                            'param_holder_class' => 'vc_colored-dropdown'
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value' => ''
                        ),
                        $add_el_class
                    )
                ) );
                $portfolio_categories = get_terms( ZORKA_PORTFOLIO_CATEGORY_TAXONOMY, array('hide_empty' => 0, 'orderby' => 'ASC') );
                $portfolio_cat = null;
                $portfolio_cat['All'] = '';
                if ( is_array( $portfolio_categories ) ) {
                    foreach ( $portfolio_categories as $cat ) {
                        $portfolio_cat[$cat->name] = $cat->slug;
                    }
                }
                vc_map( array(
                    'name'     => __( 'Portfolio', 'zorka' ),
                    'base'     => 'zorka_portfolio',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Portfolio Category', 'zorka' ),
                            'param_name'  => 'category',
                            'admin_label' => true,
                            'value'       => $portfolio_cat
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Show Category', 'zorka' ),
                            'param_name'  => 'show_category',
                            'admin_label' => true,
                            'value'       => array( 'None' => '', __('Show in left','zorka') => 'left', __('Show in center','zorka') => 'center', __('Show in right','zorka') => 'right')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Number of column', 'zorka' ),
                            'param_name'  => 'column',
                            'value'       => array( '2' => '2', '3' => '3', '4' => '4')
                        ),
                        array(
                            'type'        => 'textfield',
                            'heading'     => __( 'Number of item (or number of item per page if choose show paging)', 'zorka' ),
                            'param_name'  => 'item',
                            'value'       => ''
                        ),
                        array(
                            'type'        => 'checkbox',
                            'heading'     => __( 'Show Paging (or show loading more)', 'zorka' ),
                            'param_name'  => 'show_pagging',
                            'admin_label' => true,
                            'value'       => array( __( 'Show', 'zorka' ) => '1')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Padding', 'zorka' ),
                            'param_name'  => 'padding',
                            'value'       =>  array( __( 'No padding', 'zorka' ) => '', '10 px' => 'col-padding-10', '15 px' => 'col-padding-15', '20 px' => 'col-padding-20', '40 px' => 'col-padding-40')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Type', 'zorka' ),
                            'param_name'  => 'layout_type',
                            'admin_label' => true,
                            'value'       => array(__( 'Grid', 'zorka' ) => 'grid',__( 'Info', 'zorka' ) => 'info')
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Overlay Style', 'zorka' ),
                            'param_name'  => 'overlay_style',
                            'admin_label' => true,
                            'value'       => array( __( 'Icon', 'zorka' ) => 'icon', __( 'Title & Category', 'zorka' ) => 'title',
                                                    __( 'Icon & Title', 'zorka' ) => 'icon-view', __('Zoom Out','zorka') => 'zoom-out'
                                                    )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation

                    )
                ));


                vc_map( array(
                    "name"     => __( "Countdown", "zorka" ),
                    "base"     => "zorka_countdown",
                    "class"    => "",
                    "icon"     => "icon-wpb-title",
                    "category" => __( 'Zorka Shortcodes', 'zorka' ),
                    "params"   => array(
                        array(
                            "type"        => "dropdown",
                            "heading"     => __( "Countdown Type", "zorka" ),
                            "param_name"  => "type",
                            "admin_label" => true,
                            "value"       => array( __('Coming Soon','zorka') => 'comming-soon', __('Under Construction','zorka') => 'under-construction')
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Extra class name", "zorka" ),
                            "param_name"  => "css",
                            "value"       => '',
                            "description" => __( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", "zorka" )
                        ),
                    )
                ));

                $product_categories = array();
                $product_cat = array();
                if(class_exists( 'WooCommerce' )){
                    $args = array(
                        'number'     => '',
                    );
                    $product_categories = get_terms( 'product_cat', $args );
                    if ( is_array( $product_categories ) ) {
                        foreach ( $product_categories as $cat ) {
                            $product_cat[$cat->name] = $cat->slug;
                        }
                    }
                }

                vc_map( array(
                    "name"     => __( "Product", "zorka" ),
                    "base"     => "zorka_product",
                    "class"    => "",
                    "icon"     => "icon-wpb-title",
                    "category" => __( 'Zorka Shortcodes', 'zorka' ),
                    "params"   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Style', 'zorka' ),
                            'param_name'  => 'style',
                            'value'       => array( __( 'Style 1', 'zorka' ) => '',
                                __( 'Style 2', 'zorka' ) => 'product-style-two',
                                __( 'Style 3', 'zorka' ) => 'product-style-three',
                                __( 'Style 4', 'zorka' ) => 'product-style-four'
                            )

                        ),

                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Title", "zorka" ),
                            "param_name"  => "title",
                            "admin_label" => true,
                            "value"       => '',
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Title style', 'zorka' ),
                            'param_name'  => 'title_style',
                            'value'       => array( __( 'Border bottom inline', 'zorka' ) => '',
                                __( 'Border bottom full', 'zorka' ) => 'border-title-full'),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Padding', 'zorka' ),
                            'param_name'  => 'padding',
                            'value'       => array(  __( 'No Padding', 'zorka' ) => '',
                                __( 'Padding 10px', 'zorka' ) => 'zorka-padding-10',
                                __( 'Padding 15px', 'zorka' ) => 'zorka-padding-15',
                                __( 'Padding 20px', 'zorka' ) => 'zorka-padding-20',
                            ),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )
                        ),
                        array(
                            'type'        => 'colorpicker',
                            'heading'     => __( 'Background color', 'zorka' ),
                            'param_name'  => 'bg_color',
                            'value'       => '',
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Select product source', 'zorka' ),
                            'param_name'  => 'source',
                            'value'       => array( __( 'From feature', 'zorka' ) => 'feature',
                                                    __( 'From category', 'zorka' ) => 'category',
                                                 ),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )

                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Feature', 'zorka' ),
                            'param_name'  => 'filter',
                            'value'       => array( __( 'Sale Off', 'zorka' ) => 'sale-product',
                                                    __( 'New In', 'zorka' ) => 'new-in',
                                                    __( 'Featured', 'zorka' ) => 'featured',
                                                    __( 'Top rated', 'zorka' ) => 'top-rated',
                                                    __( 'Recent review', 'zorka' ) => 'recent-review'),


                        ),
                        array(
                            'type' => 'multi-select',
                            'heading' => __( 'Category', 'zorka' ),
                            'param_name' => 'category',
                            'options' => $product_cat,
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Show button compare & wishlist', 'zorka' ),
                            'param_name'  => 'show_compare_wish_list_button',
                            'value'       => array(  __( 'Yes', 'zorka' ) => '',
                                __( 'No', 'zorka' ) => 'hide-button',
                            ),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-four') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Show sale countdown', 'zorka' ),
                            'param_name'  => 'show_sale_count_down',
                            'value'       => array(  __( 'Yes', 'zorka' ) => '',
                                __( 'No', 'zorka' ) => 'hide-count-down',
                            ),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-four') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Show rating', 'zorka' ),
                            'param_name'  => 'show_rating',
                            'value'       => array(  __( 'Yes', 'zorka' ) => '1',
                                __( 'No', 'zorka' ) => '0',
                            ),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-four') )
                        ),

                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Per Page", "zorka" ),
                            "param_name"  => "per_page",
                            "admin_label" => true,
                            "value"       => '',
                            "description" => __('How much items per page to show','zorka')
                        ),
                        array(
                            "type"        => "dropdown",
                            "heading"     => __( "Columns", "zorka" ),
                            "param_name"  => "columns",
                            'value'       => array(
                                '5' => '5',
                                '4' => '4',
                                '3' => '3',
                                '2' => '2'
                            ),
                            "description" => __( "How much columns grid", "zorka" )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Display Slider', 'zorka' ),
                            'param_name'  => 'slider',
                            'value'       => array( __( 'No', 'zorka' ) => '', __( 'Yes', 'zorka' ) => 'slider'),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )

                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Navigator position', 'zorka' ),
                            'param_name'  => 'navigator_position',
                            'value'       => array( __( 'Center', 'zorka' ) => 'center', __( 'Top - right', 'zorka' ) => 'top-right'),
                            'dependency'  => Array( 'element' => 'style', 'value' => array( '','product-style-two','product-style-three') )

                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order by', 'zorka' ),
                            'param_name'  => 'orderby',
                            'value'       => array( __( 'Date', 'zorka' ) => 'date', __( 'ID', 'zorka' ) => 'ID',
                                                    __( 'Author', 'zorka' ) => 'author', __( 'Modified', 'zorka' ) => 'modified',
                                                    __( 'Random', 'zorka' ) => 'rand', __( 'Comment count', 'zorka' ) => 'comment_count',
                                                    __( 'Menu Order', 'zorka' ) => 'menu_order'
                                                    ),
                            'description' => __( 'Select how to sort retrieved products.', 'zorka' ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order way', 'zorka' ),
                            'param_name'  => 'order',
                            'value'       => array( __( 'Descending', 'zorka' ) => 'DESC', __( 'Ascending', 'zorka' ) => 'ASC'),
                            'description' => __( 'Designates the ascending or descending order.', 'zorka' ),
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ));


                vc_map( array(
                    "name"     => __( "Trending Product", "zorka" ),
                    "base"     => "zorka_trending_product",
                    "class"    => "",
                    "icon"     => "icon-wpb-title",
                    "category" => __( 'Zorka Shortcodes', 'zorka' ),
                    "params"   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Title", "zorka" ),
                            "param_name"  => "title",
                            "admin_label" => true,
                            "value"       => '',
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style2') )
                        ),
                        array(
                            'type' => 'multi-select',
                            'heading' => __( 'Product Category', 'zorka' ),
                            'param_name' => 'category',
                            'options' => $product_cat
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Display Featured Product', 'zorka' ),
                            'param_name' => 'display_featured',
                            'value' =>  array( __( 'Show', 'zorka' ) => '1'),
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1') )
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Per Page", "zorka" ),
                            "param_name"  => "per_page",
                            "admin_label" => true,
                            "value"       => '',
                            "description" => __('How much items per page to show','zorka')
                        ),
                        array(
                            "type"        => "textfield",
                            "heading"     => __( "Columns", "zorka" ),
                            "param_name"  => "columns",
                            "value"       => '4',
                            "description" => __( "How much columns grid", "zorka" )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Slider', 'zorka' ),
                            'param_name'  => 'slider',
                            'value'       => array( __( 'No', 'zorka' ) => '',
                                            __( 'Yes', 'zorka' ) => 'slider'
                            ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order by', 'zorka' ),
                            'param_name'  => 'orderby',
                            'value'       => array( __( 'Date', 'zorka' ) => 'date', __( 'ID', 'zorka' ) => 'ID',
                                __( 'Author', 'zorka' ) => 'author', __( 'Modified', 'zorka' ) => 'modified',
                                __( 'Random', 'zorka' ) => 'rand', __( 'Comment count', 'zorka' ) => 'comment_count',
                                __( 'Menu Order', 'zorka' ) => 'menu_order'
                            ),
                            'description' => __( 'Select how to sort retrieved products.', 'zorka' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order way', 'zorka' ),
                            'param_name'  => 'order',
                            'value'       => array( __( 'Descending', 'zorka' ) => 'DESC', __( 'Ascending', 'zorka' ) => 'ASC'),
                            'description' => __( 'Designates the ascending or descending orde.', 'zorka' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ));

                vc_map(array(
                    'name' => __('Product Categories','zorka'),
                    'base' => 'zorka_product_categories',
                    'class' => '',
                    'icon' => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params' => array(
                        array(
                            'type' => 'multi-select',
                            'heading' => __( 'Product Category', 'zorka' ),
                            'param_name' => 'category',
                            'options' => $product_cat
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Number Column', 'zorka' ),
                            'param_name'  => 'columns',
                            'admin_label' => true,
                            'value'       => array('3' => 3,'4' => 4, '5' => '5'),
                            'std'   => '5',
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Slider', 'zorka' ),
                            'param_name'  => 'slider',
                            'value'       => array( __( 'No', 'zorka' ) => '',
                                __( 'Yes', 'zorka' ) => 'slider'
                            ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Hide empty', 'zorka' ),
                            'param_name'  => 'hide_empty',
                            'value'       => array( __( 'No', 'zorka' ) => '0',
                                __( 'Yes', 'zorka' ) => '1'
                            ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order by', 'zorka' ),
                            'param_name'  => 'orderby',
                            'value'       => array( __( 'Date', 'zorka' ) => 'date', __( 'ID', 'zorka' ) => 'ID',
                                __( 'Author', 'zorka' ) => 'author', __( 'Modified', 'zorka' ) => 'modified',
                                __( 'Random', 'zorka' ) => 'rand', __( 'Comment count', 'zorka' ) => 'comment_count',
                                __( 'Menu Order', 'zorka' ) => 'menu_order'
                            ),
                            'description' => __( 'Select how to sort retrieved products.', 'zorka' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Order way', 'zorka' ),
                            'param_name'  => 'order',
                            'value'       => array( __( 'Descending', 'zorka' ) => 'DESC', __( 'Ascending', 'zorka' ) => 'ASC'),
                            'description' => __( 'Designates the ascending or descending orde.', 'zorka' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ));

                vc_map( array(
                    'name'     => __( 'Our Team', 'zorka' ),
                    'base'     => 'zorka_our_team',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'        => 'checkbox',
                            'heading'     => __( 'Slider Style', 'zorka' ),
                            'param_name'  => 'is_slider',
                            'admin_label' => false,
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' ),
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Number Column', 'zorka' ),
                            'param_name'  => 'column',
                            'admin_label' => true,
                            'value'       => array('1' => 1,'2' => 2,'3' => 3,'4' => 4),
                            'std'   => '3',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Item Amount', 'zorka' ),
                            'param_name' => 'item_amount',
                            'value'      => '10',
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name'     => __( 'Testimonials', 'zorka' ),
                    'base'     => 'zorka_testimonial',
                    'class'    => '',
                    'icon'     => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'params'   => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3', __( 'style 4', 'zorka' ) => 'style4'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Sub Title', 'zorka' ),
                            'param_name' => 'sub_title',
                            'value'      => '',
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style2','style3','style4') )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ) );
                vc_map( array(
                    'name' => __( 'Latest Posts', 'zorka' ),
                    'base' => 'zorka_latest_post',
                    'icon' => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'description' => __( 'Latest Posts', 'zorka' ),
                    'params' => array(
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Layout Style', 'zorka' ),
                            'param_name'  => 'layout_style',
                            'admin_label' => true,
                            'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2'),
                            'description' => __( 'Select Layout Style.', 'zorka' )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Title', 'zorka' ),
                            'param_name' => 'title',
                            'value'      => '',
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style2') )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'heading'     => __( 'Number Column', 'zorka' ),
                            'param_name'  => 'column',
                            'admin_label' => true,
                            'value'       => array('1' => 1,'2' => 2,'3' => 3,'4' => 4),
                            'std'         => '2',
                            'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1') )
                        ),
                        array(
                            'type'       => 'textfield',
                            'heading'    => __( 'Item Amount', 'zorka' ),
                            'param_name' => 'item_amount',
                            'value'      => '10'
                        ),
                        array(
                            'type'        => 'checkbox',
                            'heading'     => __( 'Slider Style', 'zorka' ),
                            'param_name'  => 'is_slider',
                            'admin_label' => false,
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' ),
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ));
                vc_map( array(
                    'name' => __( 'Partner Carousel', 'zorka' ),
                    'base' => 'zorka_partner_carousel',
                    'icon' => 'icon-wpb-title',
                    'category' => __( 'Zorka Shortcodes', 'zorka' ),
                    'description' => __( 'Animated carousel with images', 'zorka' ),
                    'params' => array(
                        array(
                            'type' => 'attach_images',
                            'heading' => __( 'Images', 'zorka' ),
                            'param_name' => 'images',
                            'value' => '',
                            'description' => __( 'Select images from media library.', 'zorka' )
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Image size', 'zorka' ),
                            'param_name' => 'img_size',
                            'description' => __( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'zorka' )
                        ),
                        array(
                            'type' => 'exploded_textarea',
                            'heading' => __( 'Custom links', 'zorka' ),
                            'param_name' => 'custom_links',
                            'description' => __( 'Enter links for each slide here. Divide links with linebreaks (Enter) . ', 'zorka' ),
                            'dependency' => array(
                                'element' => 'onclick',
                                'value' => array( 'custom_link' )
                            )
                        ),
                        array(
                            'type' => 'dropdown',
                            'heading' => __( 'Custom link target', 'zorka' ),
                            'param_name' => 'custom_links_target',
                            'description' => __( 'Select where to open  custom links.', 'zorka' ),
                            'dependency' => array(
                                'element' => 'onclick',
                                'value' => array( 'custom_link' )
                            ),
                            'value' => $target_arr
                        ),
                        array(
                            'type' => 'textfield',
                            'heading' => __( 'Slides per view', 'zorka' ),
                            'param_name' => 'column',
                            'value' => '5',
                            'description' => __( 'Set numbers of slides you want to display', 'zorka' )
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Slider autoplay', 'zorka' ),
                            'param_name' => 'autoplay',
                            'description' => __( 'Enables autoplay mode.', 'zorka' ),
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        array(
                            'type' => 'checkbox',
                            'heading' => __( 'Show pagination control', 'zorka' ),
                            'param_name' => 'pagination',
                            'value' => array( __( 'Yes, please', 'zorka' ) => 'yes' )
                        ),
                        $add_el_class,
                        $add_css_animation,
                        $add_duration_animation,
                        $add_delay_animation
                    )
                ));
                vc_map(
                    array(
                        'name'                    => __( 'MailChimp', 'zorka' ),
                        'base'                    => 'zorka_mailchimp',
                        'icon'                    => 'icon-wpb-title',
                        'category'                => __( 'Zorka Shortcodes', 'zorka' ),
                        'params'                  => array(
                            array(
                                'type'        => 'dropdown',
                                'heading'     => __( 'Layout Style', 'zorka' ),
                                'param_name'  => 'layout_style',
                                'admin_label' => true,
                                'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2'),
                                'description' => __( 'Select Layout Style.', 'zorka' )
                            ),
                            array(
                                'type'        => 'icon_text',
                                'heading'     => __( 'Select Icon:', 'zorka' ),
                                'param_name'  => 'icon',
                                'value'       => '',
                                'description' => __( 'Select the icon from the list.', 'zorka' ),
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __( 'Title', 'zorka' ),
                                'param_name'  => 'title',
                                'value'       => '',
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __( 'Sub Title', 'zorka' ),
                                'param_name'  => 'sub_title',
                                'value'       => '',
                            ),
                            $add_el_class,
                            $add_css_animation,
                            $add_duration_animation,
                            $add_delay_animation
                        )
                    )
                ); // end vc_map
                vc_map(
                    array(
                        'name'                    => __( 'Icon Box', 'zorka' ),
                        'base'                    => 'zorka_icon_box',
                        'icon'                    => 'icon-wpb-title',
                        'category'                => __( 'Zorka Shortcodes', 'zorka' ),
                        'description'             => 'Adds icon box with font icons',
                        'params'                  => array(
                            array(
                                'type'        => 'dropdown',
                                'heading'     => __( 'Layout Style', 'zorka' ),
                                'param_name'  => 'layout_style',
                                'admin_label' => true,
                                'value'       => array( __( 'style 1', 'zorka' ) => 'style1', __( 'style 2', 'zorka' ) => 'style2', __( 'style 3', 'zorka' ) => 'style3', __( 'style 4', 'zorka' ) => 'style4', __( 'style 5', 'zorka' ) => 'style5'),
                                'description' => __( 'Select Layout Style.', 'zorka' )
                            ),
                            array(
                                'type'        => 'icon_text',
                                'heading'     => __( 'Select Icon:', 'zorka' ),
                                'param_name'  => 'icon',
                                'value'       => '',
                                'description' => __( 'Select the icon from the list.', 'zorka' ),
                            ),
                            array(
                                'type'        => 'dropdown',
                                'heading'     => __( 'Icon position', 'zorka' ),
                                'param_name'  => 'icon_position',
                                'value'       => array( __( 'left', 'zorka' ) => 'left', __( 'right', 'zorka' ) => 'right', __( 'center', 'zorka' ) => 'center'),
                                'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1','style2' ) )
                            ),
                            array(
                                'type'        => 'colorpicker',
                                'heading'     => __( 'Icon Background Color', 'zorka' ),
                                'param_name'  => 'icon_bg_color',
                                'value'       => '',
                                'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style5') )
                            ),
                            array(
                                'type'        => 'colorpicker',
                                'heading'     => __( 'Background Color', 'zorka' ),
                                'param_name'  => 'bg_color',
                                'value'       => '',
                                'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style5') )
                            ),
                            array(
                                'type'       => 'textfield',
                                'heading'    => __( 'Link (url)', 'zorka' ),
                                'param_name' => 'link',
                                'value'      => '#',
                            ),
                            array(
                                'type'        => 'textfield',
                                'heading'     => __( 'Title', 'zorka' ),
                                'param_name'  => 'title',
                                'value'       => '',
                                'description' => __( 'Provide the title for this icon box.', 'zorka' ),
                            ),
                            array(
                                'type'        => 'textarea',
                                'heading'     => __( 'Description', 'zorka' ),
                                'param_name'  => 'description',
                                'value'       => '',
                                'description' => __( 'Provide the description for this icon box.', 'zorka' ),
                                'dependency'  => Array( 'element' => 'layout_style', 'value' => array( 'style1','style3','style4' ) )
                            ),
                            $add_el_class,
                            $add_css_animation,
                            $add_duration_animation,
                            $add_delay_animation
                        )
                    )
                ); // end vc_map                               
            }
        }
    }
    new Zorka_Shortcode;
}