FILTERS IN XMENU
----------------
1. xmenu_filter_before
2. xmenu_filter_after
3. xmenu_nav_filter_before
4. xmenu_nav_filter_after
5. xmenu_filter_toggle
6. xmenu_filter_mobile_toggle_icon
7. xmenu_filter_mobile_toggle_text
8. xmenu_toggle_inner_before
9. xmenu_toggle_inner_after